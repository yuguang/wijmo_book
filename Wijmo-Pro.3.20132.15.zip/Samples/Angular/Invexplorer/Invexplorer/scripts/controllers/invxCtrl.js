﻿// define controller
function invxCtrl($scope) {
    $scope.viewModel = new viewModel($scope);
}
