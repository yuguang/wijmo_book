8CFF0D7D-30A9-4B80-83E6-D04638D72511		Common Guid shared by sample with multiple languages.
F2DA086D-7477-4B52-91CD-D74614D4E439		Unique Guid for each sample regardless of language.
