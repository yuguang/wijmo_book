B745309D-B07D-4418-AA9D-1DC9657D4071		Common Guid shared by sample with multiple languages.
E1343A1B-A5B2-4C31-B0B6-391F7BC2500B		Unique Guid for each sample regardless of language.
